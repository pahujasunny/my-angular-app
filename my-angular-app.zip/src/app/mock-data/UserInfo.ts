import { User } from '../classes/user';

export const USERINFO: User = { id: 1, name: 'Sunny Pahuja', role: 'Administrator' };
