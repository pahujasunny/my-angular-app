    import { User } from '../classes/user';

    export const USERLIST: Array<User>  = [{
    id: 1,
    name: 'Sunny',
    role: 'Administrator'
},
{
    id: 2,
    name: 'Saurabh',
    role: 'User'
},
{
    id: 3,
    name: 'Mayank',
    role: 'Read Only'
},
{
    id: 4,
    name: 'Prabhjinder',
    role: 'People Manager'
},
{
    id: 5,
    name: 'John',
    role: 'Visitor'
}
];
