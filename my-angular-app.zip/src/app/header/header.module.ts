import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HeaderComponent } from './header.component';
import { NavBarComponent } from '../navbar/navbar.component';
//import { UserInfoComponent } from '../userInfo/userInfo.component';


@NgModule({
  declarations: [
    HeaderComponent, NavBarComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [HeaderComponent]
})

export class HeaderModule { }
