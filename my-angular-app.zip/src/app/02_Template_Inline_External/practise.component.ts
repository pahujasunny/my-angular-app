import { Component } from '../../../node_modules/@angular/core';

@Component({
  selector: 'app-practise',
  templateUrl: './practise.component.html',
  styleUrls: ['./practise.Component.css']
})
export class PractiseComponent {
  DisplayText = 'My First Practise Angular App.';
}
