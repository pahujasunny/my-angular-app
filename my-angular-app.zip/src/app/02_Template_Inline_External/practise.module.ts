import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { PractiseComponent } from './practise.component';


@NgModule({
  declarations: [
    PractiseComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [PractiseComponent]
})

export class PractiseModule { }
