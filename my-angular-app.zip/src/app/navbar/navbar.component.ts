import { Component } from '../../../node_modules/@angular/core';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html'
})

export class NavBarComponent {
  // CompanyTagLine = 'My First Practise Angular App.';
}

