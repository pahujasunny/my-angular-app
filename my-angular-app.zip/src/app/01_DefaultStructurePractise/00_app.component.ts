import { Component } from '../../../node_modules/@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './00_app.component.html',
  styleUrls: ['./00_app.Component.css']
})
export class AppComponent {
  title = 'My First Angular App.';
}
